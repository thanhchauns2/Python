# Tiny Python Projects Docker

If you like, you can run and test all the code using Python 3.8.3 in a Docker image:

```
$ docker pull kyclark/tiny_python_projects:0.2.0
$ docker run -it --rm kyclark/tiny_python_projects:0.2.0 bash
```
