#!/usr/bin/env python3

import pandas as pd

df = pd.read_csv('inputs/exercises.csv')
print(df)
