# Purpose: Say hello
print('Hello, World!')
