#!/usr/bin/env python3
# Purpose: Say hello
print('Hello, World!')
